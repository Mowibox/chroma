---
title: "Launching a Discord Server"
description: "Join the official Chroma Discord server to discuss tutorials, computer vision, and technical projects."
summary: "Creation and launch of Chroma's official Discord server"
date:  2025-07-01T01:16:05+02:00
lastmod:  2025-07-01T01:16:05+02:00
draft: false
weight: 49
categories: []
tags: ["discord", "community", "chroma"]
contributors: ["Ousmane THIONGANE"]
pinned: false
homepage: false
seo:
  title: "Join the official Chroma Discord server" # custom title (optional)
  description: "Join the discussions on Chroma, ask questions, and exchange ideas about tutorials and projects." # custom description (recommended)
  canonical: "https://mowibox.github.io/chroma/en/blog/launching-a-discord-server/" # custom canonical URL (optional)
  noindex: false
  robots: "index, follow" # custom robot tags (optional)
---

<p align="center">
    <img src="/chroma/images/discord.jpg" alt="Discord logo" class="w-full h-auto" />
    </br>
</p>

In keeping with the goal of making Chroma a collaborative space, I’m excited to announce the launch of the **Chroma Discord server**! :tada:

This server is designed to foster discussions among anyone interested in the topics explored on the site — whether you're looking to ask questions, get help with tutorials, or simply share and chat about various projects.

💡 **All contributions and suggestions are welcome!**

## How to join?

You can join by clicking the Discord icon in the site’s navigation menu, or directly through this link:
:point_right: [Join the Chroma Discord server](https://discord.gg/CwP7xzzsds)

🔴🟠🟡🟢🔵🟣

**See you soon on the server!**
